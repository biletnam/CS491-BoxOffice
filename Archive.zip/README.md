# CS491-BoxOffice

Scraping for Data:
  1. Navigate to the code folder in command prompt
  2. Enter the following command:
      $ python scraper.py "MOVIE TITLE" YYYY MM DD YYYY MM DD "FILE.JSON"
        - Enter start date first, finish date second
        
The program will scrape for Twitter data between the provided dates and save the data in JSON format in the designated file.
